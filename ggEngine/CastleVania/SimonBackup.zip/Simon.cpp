#include "Simon.h"
#include "CVGame.h"
#include "CVAdd.h"
#include "ItemManager.h"
#include "WeaponManager.h"
Simon::Simon(CVGame *cvGame, SpriteInfo * image,InfoPanel *infoPanel, int frameWidth, int frameHeight, int defaultFrame, int numberOfFrame, DWORD msPerFrame)
	: CharacterBase(cvGame, image, frameWidth, frameHeight, defaultFrame, numberOfFrame, msPerFrame)
{
	this->weaponManager = cvGame->weaponManager;

	this->tag = ObjectType_Simon;
	this->health = 16;
	this->maxHealth = 16;
	this->infoPanel = infoPanel;
	this->SetPosition(0, 0);
	this->SetAnchor(0.5, 0.5);
	this->SetScale(1, 1);
	this->SetHealth(health);
	this->CreateAnimation("idle", 0, 0, true);
	this->CreateAnimation("move", 1, 2, true);
	this->CreateAnimation("kneel", 4, 4, true);
	this->CreateAnimation("climbDown", 5, 6, true);
	this->CreateAnimation("climbDownIdle", 5, 5, true);
	this->CreateAnimation("climbUp", 7, 8, true);
	this->CreateAnimation("climbUpIdle", 7, 7, true);
	this->CreateAnimation("behind", 9, 9, true);
	this->CreateAnimation("hurt", 10, 10, true);
	this->CreateAnimation("death", 11, 11, true);

	//Create "after ... attack" to double the frame which whip is shown longest
	//Stand Attack
	this->CreateAnimation("standAttack", { 12,13,14,14 }, false);

	// Kneel Attack
	this->CreateAnimation("kneelAttack", { 15,16,17,17 }, false);

	//Climb Down Attack
	this->CreateAnimation("climbDownAttack", { 18,19,20,20 }, false);

	//Climb Up Attack
	this->CreateAnimation("climbUpAttack", { 21,22,23,23 }, false);



	this->cvGame->physics->EnablePhysics(this);
	this->body->CreateRectangleRigidBody(14, 26);
	this->body->syncBounds = false;
	this->body->rigidBody->SetAnchor(0.5, 0.32);
	this->body->allowGravity = true;
	this->body->allowWorldBounciness = false;
	this->body->allowWorldBlock = true;
	this->events->onCheckingCollide = [this](GameObject *object, ColliderArg e) {
		GameObject *otherObject = e.colliderObject;
		Tag type = otherObject->tag;
		switch (type) {
		case ObjectType_LadderDownLeft:
			this->ladderState = LadderDownLeft;
			return false;
		case ObjectType_LadderDownRight:
			this->ladderState = LadderDownRight;
			return false;
		case ObjectType_LadderUpLeft:
			if (e.blockDirection.down) {
				this->ladderState = LadderUpLeft;
				this->grounding = GroundingBrick;
				return true;
			}
			return false;
		case ObjectType_LadderUpRight:
			//if (e.blockDirection.down && this->isClimbingUp) {
			if (this->isClimbingUp){
				this->ladderState = LadderUpRight;
				this->grounding = GroundingBrick;
				return true;
			}
			return false;
		case ObjectType_Static:
			return true;
		case ObjectType_LevelTwoBrick:
			return true;
		default:
			return false;
		}
		return false;

	};
	this->events->onCollide = [this](GameObject *object, ColliderArg e) {
		GameObject *otherObject = e.colliderObject;
		Tag type = otherObject->tag;
		switch (type) {
		case ObjectType_LevelTwoBrick:
			if (e.blockDirection.down) {
				this->ladderState = LadderNone;
				this->grounding = GroundingBrick;
			}
			break;
		case ObjectType_Candle:
			//g_debug.Log("Collided with candle");
			break;
		case ObjectType_LadderDownLeft:
			break;
		case ObjectType_LadderDownRight:
			break;
		case ObjectType_LadderUpLeft:
			break;
		case ObjectType_LadderUpRight:
			break;
		case ObjectType_Static:
		case ObjectType_Item:
			if (otherObject->events->onCollide != nullptr) {
				ColliderArg	o = Physics::CreateOppositeColliderArg(e, object);
				otherObject->events->onCollide(otherObject, o);
			}
			break;
		default:
			break;
		}

	};
	this->events->onWorldBounds = [this](GameObject *go, ColliderArg e) {
		if (e.blockDirection.down) {
		}
	};

	this->cvGame->eventManager->EnableKeyBoardInput(this);
	this->events->onKeyPress = [this](GameObject *go, KeyBoardEventArg e) {
		OnKeyBoardEventReceive(e);
	};
	
	this->SetUpKeyControl();
	this->shot = 1;
	this->score = 0;
	this->stagePoint = 1;
	this->heartPoint = 5;
	this->pPoint = 3;
}

Simon::~Simon()
{
	if (this->weaponWhip != nullptr) {
		delete this->weaponWhip;
	}
}

void Simon::SetHealth(int heath)
{
	this->health = heath;
	if (this->health < 0) this->health = 0;
	if (this->health > this->maxHealth) this->health = this->maxHealth;
	if (infoPanel != nullptr) {
		infoPanel->SetPlayerHealth(this->health);
	}
	if (this->health == 0) Death();
}

void Simon::Attack()
{
	this->weaponManager->AddWeaponBoomerang(position.x, position.y, direction == FacingDirection_Left, this->parentGroup);
}

void Simon::WhipAttack()
{
}

void Simon::AddWhip()
{
	this->weaponWhip = this->weaponManager->AddWeaponWhip(0, 8, direction == FacingDirection_Left, this->parentGroup);
	this->weaponWhip->SetAnchor(0.64, 0.5);
	this->weaponWhip->SetTransformBasedOn(this);
}



void Simon::Idle()
{
	this->PlayAnimation("idle");
	this->body->velocity.x = 0;
}

void Simon::MoveLeft()
{
	this->PlayAnimation("move");
	ChangeFacingDirection(FacingDirection_Left);
	this->body->velocity.x = -CharacterConstant::SIMON_MOVE_FORCE;
}

void Simon::MoveRight()
{
	this->PlayAnimation("move");
	ChangeFacingDirection(FacingDirection_Right);
	this->body->velocity.x = CharacterConstant::SIMON_MOVE_FORCE;
}

void Simon::Jump()
{
	if (grounding == GroundingBrick)
	{
		this->PlayAnimation("kneel");
		this->body->velocity.y = -CharacterConstant::SIMON_JUMP_FORCE;
		//this->weaponWhip->body->velocity.y = -CharacterConstant::SIMON_JUMP_FORCE;
		grounding = GroundingNone;
	}
}

void Simon::Kneel()
{
	this->PlayAnimation("kneel");
	this->body->velocity.x = 0;
}

void Simon::ClimbUpLeft()
{
	this->PlayAnimation("climbUp");
	this->isClimbingUp = true;
	ChangeFacingDirection(FacingDirection_Left);
	this->body->velocity.x = -CharacterConstant::SIMON_CLIMB_FORCE;
	this->body->velocity.y = -CharacterConstant::SIMON_CLIMB_FORCE;
}

void Simon::ClimbUpRight()
{
	this->PlayAnimation("climbUp");
	this->isClimbingUp = true;
	ChangeFacingDirection(FacingDirection_Right);
	this->body->velocity.x = CharacterConstant::SIMON_CLIMB_FORCE;
	this->body->velocity.y = -CharacterConstant::SIMON_CLIMB_FORCE;
}

void Simon::ClimbDownLeft()
{
	this->PlayAnimation("climbDown");
	this->isClimbingUp = false;
	ChangeFacingDirection(FacingDirection_Left);
	this->body->velocity.x = -CharacterConstant::SIMON_CLIMB_FORCE;
	this->body->velocity.y = CharacterConstant::SIMON_CLIMB_FORCE;
}

void Simon::ClimbDownRight()
{
	this->PlayAnimation("climbDown");
	this->isClimbingUp = false;
	ChangeFacingDirection(FacingDirection_Right);
	this->body->velocity.x = CharacterConstant::SIMON_CLIMB_FORCE;
	this->body->velocity.y = CharacterConstant::SIMON_CLIMB_FORCE;
}

void Simon::ClimbIdle()
{
	this->body->velocity.x = 0;
	this->body->velocity.y = 0;

	if (this->isClimbingUp)
		PlayAnimation("climbUpIdle");
	else
		PlayAnimation("climbDownIdle");
}

void Simon::ClimbUpFinish()
{
	this->PlayAnimation("Idle");
	this->body->velocity.x = 0;
	this->body->velocity.y = 0;
	this->grounding = GroundingBrick;
}

void Simon::Hurt()
{
	this->PlayAnimation("hurt");
	this->Blind();
	//this->body->SetEnable(false);

	Vector direction(1, -3);
	if (this->direction == FacingDirection_Left)
		direction.x = -1;
	this->body->AddForce(hurtForce, direction);

	this->cvGame->add->TimeOut(2000, [this] {
		//this->body->SetEnable(true);
	})->Start();

}

void Simon::Death()
{
	this->PlayAnimation("death");
	this->body->velocity.x = 0;
}

void Simon::StandAttack()
{
	this->body->velocity.x = 0;
	this->PlayAnimation("standAttack");
	this->incompleteAnim = "standAttack";
	//this->WhipAttack();
	this->weaponWhip->StandAttack(direction);
}

void Simon::KneelAttack()
{
	this->body->velocity.x = 0;
	this->PlayAnimation("kneelAttack");
	this->incompleteAnim = "kneelAttack";
	this->weaponWhip->KneelAttack(direction);
}

void Simon::ClimbDownAttack()
{
	this->body->velocity.x = 0;
	this->body->velocity.y = 0;
	this->PlayAnimation("climbDownAttack");
	this->incompleteAnim = "climbDownAttack";
	this->weaponWhip->ClimbDownAttack(direction);
}

void Simon::ClimbUpAttack()
{
	this->body->velocity.x = 0;
	this->body->velocity.y = 0;
	this->PlayAnimation("climbUpAttack");
	this->incompleteAnim = "climbUpAttack";
	this->weaponWhip->ClimbUpAttack(direction);
}

void Simon::ClimbAttack()
{
	if (this->isClimbingUp)
		this->ClimbUpAttack();
	else
		this->ClimbDownAttack();
}

void Simon::LoseHealth(int health)
{
	this->health -= health;
	if (this->health < 0) this->health = 0;
	if (infoPanel != nullptr) {
		infoPanel->SetPlayerHealth(this->health);
	}
	if (this->health == 0) Death();
}

void Simon::GainHealth(int health)
{
	this->health += health;
	if (this->health > this->maxHealth) this->health = this->maxHealth;
	if (infoPanel != nullptr) {
		infoPanel->SetPlayerHealth(this->health);
	}
}

void Simon::IncreaseScore(int score)
{
	this->score += score;
	this->infoPanel->SetScore(this->score);
}

void Simon::IncreaseState()
{
	if(infoPanel!=nullptr) this->infoPanel->SetState(++this->stagePoint);
}

void Simon::IncreaseHeartPoint(int point)
{
	this->heartPoint += point;
	if (infoPanel != nullptr) this->infoPanel->SetLife(heartPoint);
}

void Simon::DecreaseHeartPoint(int point)
{
	this->heartPoint = (heartPoint - point <= 0) ? 0 : heartPoint - point;
	if (infoPanel != nullptr) this->infoPanel->SetLife(this->heartPoint);
}

void Simon::DescreasePPoint(int point)
{
	this->pPoint = (pPoint - point <= 0) ? 0 : pPoint - point;
	if (infoPanel != nullptr) this->infoPanel->SetLife(this->pPoint);
}



void Simon::SetShot(int shot, SpriteInfo * image)
{
	this->shot = shot;
	this->infoPanel->itemShot->SetImage(image);
}

void Simon::UpgradeWhip()
{
	this->weaponWhip->UpgradeWhip();

	this->Blind();
	// Will be changed to stopTime
	this->cvGame->eventManager->DisableKeyBoardInput(this);
	this->body->velocity.x = 0;
	this->Idle();
	this->cvGame->add->TimeOut(2000, [this] {
		this->cvGame->eventManager->EnableKeyBoardInput(this);
	})->Start();
}

void Simon::Blind()
{
	this->cvGame->add->Loop(100, 20, [this] {
		this->SetVisible(!this->IsVisible());
	})->Start();
}

void Simon::OnKeyBoardEventReceive(KeyBoardEventArg e)
{
	DisableKeyControl();
	KeyCombine keyCombine = GetKeyCombineBaseOnPress(e);
}

void Simon::DisableKeyControl()
{
	ResetValidKey();
	switch (this->currentSimonState)
	{
	case SimonState_IdleGround:
		break;
	case SimonState_IdleLadder:
		break;
	case SimonState_MovingLadderUp:
		controlValid[SimonControl_B] = false;
		break;
	case SimonState_MovingLadderDown:
		controlValid[SimonControl_B] = false;
		break;
	case SimonState_MovingGround:
		break;
	case SimonState_Knee:
		controlValid[SimonControl_B] = false;
		break;
	case SimonState_OnLadderRight:
		controlValid[SimonControl_B] = false;
		break;
	case SimonState_OnLadderLeft:
		controlValid[SimonControl_B] = false;
		break;
	case SimonState_PreLadderRight:
		break;
	case SimonState_PreLadderLeft:
		break;
	case SimonState_Jumping:
		controlValid[SimonControl_Left] = false;
		controlValid[SimonControl_Right] = false;
		controlValid[SimonControl_B] = false;
		break;
	case SimonState_Hurting:
		controlValid[SimonControl_Left] = false;
		controlValid[SimonControl_Right] = false;
		controlValid[SimonControl_B] = false;
		break;
	case SimonState_AttackingKnee:
		controlValid[SimonControl_Left] = false;
		controlValid[SimonControl_Right] = false;
		controlValid[SimonControl_B] = false;
		controlValid[SimonControl_A] = false;
		controlValid[SimonControl_TurboA] = false;
		controlValid[SimonControl_TurboB] = false;
	case SimonState_AttackingGround:
		controlValid[SimonControl_Left] = false;
		controlValid[SimonControl_Right] = false;
		controlValid[SimonControl_B] = false;
		controlValid[SimonControl_A] = false;
		controlValid[SimonControl_TurboA] = false;
		controlValid[SimonControl_TurboB] = false;
	case SimonState_AttackingJumping:
		controlValid[SimonControl_Left] = false;
		controlValid[SimonControl_Right] = false;
		controlValid[SimonControl_B] = false;
		controlValid[SimonControl_A] = false;
		controlValid[SimonControl_TurboA] = false;
		controlValid[SimonControl_TurboB] = false;
		break;
	case SimonState_AttackingLadder:
		controlValid[SimonControl_Left] = false;
		controlValid[SimonControl_Right] = false;
		controlValid[SimonControl_B] = false;
		controlValid[SimonControl_A] = false;
		controlValid[SimonControl_TurboA] = false;
		controlValid[SimonControl_TurboB] = false;
		break;
	default:
		break;
	}
}

KeyCombine Simon::GetKeyCombineBaseOnPress(KeyBoardEventArg e)
{
	if (!(IsPressKey(e, SimonControl_A) && IsPressKey(e, SimonControl_B))) {
		if (IsPressKey(e, SimonControl_A)) {
			return KeyCombine_A;
		}
		if (IsPressKey(e, SimonControl_B)) {
			return KeyCombine_B;
		}
	}
	
	if (IsPressKey(e, SimonControl_Left)) {
		if (IsPressKey(e, SimonControl_B)) {
			return KeyCombine_LeftB;
		}
		return KeyCombine_Left;
	}

	if (IsPressKey(e, SimonControl_Right)) {
		if (IsPressKey(e, SimonControl_B)) {
			return KeyCombine_RightB;
		}
		return KeyCombine_Right;
	}
	if (IsPressKey(e, SimonControl_Up)) {
		return KeyCombine_Up;
	}
	if (IsPressKey(e, SimonControl_Down)) {
		return KeyCombine_Down;
	}
	return KeyCombine_None;
}

void Simon::SetStateBaseOnKeyCombine(KeyCombine key)
{
	switch (key)
	{
	case KeyCombine_None:
		break;
	case KeyCombine_Left:
		if (this->currentSimonState == SimonState_IdleLadder) {
			if (this->ladderDirection == FacingDirection_Left) {
				if (this->direction == FacingDirection_Left) {
					this->currentSimonState = SimonState_MovingLadderUp;
				}
				else {
					this->currentSimonState = SimonState_MovingLadderDown;
				}
			}
			else {
				if (this->direction == FacingDirection_Left) {
					this->currentSimonState = SimonState_MovingLadderDown;
				}
				else {
					this->currentSimonState = SimonState_MovingLadderUp;
				}
			}
			break;
		}
		if (this->currentSimonState == SimonState_IdleGround) {
			this->currentSimonState = SimonState_MovingGround;
			break;
		}
		break;
	case KeyCombine_Right:
		if (this->currentSimonState == SimonState_IdleLadder) {
			if (this->ladderDirection == FacingDirection_Left) {
				if (this->direction == FacingDirection_Left) {
					this->currentSimonState = SimonState_MovingLadderDown;
				}
				else {
					this->currentSimonState = SimonState_MovingLadderUp;
				}
			}
			else {
				if (this->direction == FacingDirection_Left) {
					this->currentSimonState = SimonState_MovingLadderUp;
				}
				else {
					this->currentSimonState = SimonState_MovingLadderDown;
				}
			}
			break;
		}
		if (this->currentSimonState == SimonState_IdleGround) {
			this->currentSimonState = SimonState_MovingGround;
			break;
		}
		break;
	case KeyCombine_Up:
		if (this->currentSimonState == SimonState_IdleLadder) {
			this->currentSimonState = SimonState_MovingLadderUp;
			break;
		}
		break;
	case KeyCombine_Down:
		if (this->currentSimonState == SimonState_IdleLadder) {
			this->currentSimonState = SimonState_MovingLadderDown;
			break;
		}
		break;
	case KeyCombine_A:
		if (this->currentSimonState == SimonState_IdleLadder 
			|| this->currentSimonState == SimonState_MovingLadderUp
			|| this->currentSimonState == SimonState_MovingLadderDown
			) {
			this->currentSimonState = SimonState_AttackingLadder;
			break;
		}
		if (this->currentSimonState == SimonState_Jumping) {
			this->currentSimonState = SimonState_AttackingJumping;
			break;
		}
		if (this->currentSimonState == SimonState_Knee) {
			this->currentSimonState = SimonState_AttackingKnee;
			break;
		}
		this->currentSimonState = SimonState_AttackingGround;
		break;
	case KeyCombine_B:
		this->currentSimonState = SimonState_Jumping;
		break;
	case KeyCombine_TurboA:
		break;
	case KeyCombine_TurboB:
		break;
	case KeyCombine_DownA:

		break;
	case KeyCombine_DownTurboA:
		break;
	case KeyCombine_LeftB:
		break;
	case KeyCombine_RightB:
		break;
	case KeyCombine_UpA:
		if (this->currentSimonState == SimonState_IdleLadder
			|| this->currentSimonState == SimonState_MovingLadderUp
			|| this->currentSimonState == SimonState_MovingLadderDown
			) {
			this->currentSimonState = SimonState_AttackingLadder;
			break;
		}
		break;
	case KeyCombine_UpTurboA:
		break;
	default:
		break;
	}
}

bool Simon::IsPressKey(KeyBoardEventArg e, SimonControl key)
{
	return controlValid[key] && e.isPress(controlKey[key]);
}



void Simon::ResetValidKey()
{
	controlValid[SimonControl_Left] = true;
	controlValid[SimonControl_Right] = true;
	controlValid[SimonControl_Up] = true;
	controlValid[SimonControl_Down] = true;
	controlValid[SimonControl_TurboA] = true;
	controlValid[SimonControl_TurboB] = true;
	controlValid[SimonControl_A] = true;
	controlValid[SimonControl_B] = true;
}

void Simon::SetUpKeyControl()
{
	controlKey[SimonControl_Left] = DIK_LEFT;
	controlKey[SimonControl_Right] = DIK_RIGHT;
	controlKey[SimonControl_Up] = DIK_UP;
	controlKey[SimonControl_Down] = DIK_DOWN;
	controlKey[SimonControl_TurboA] = DIK_E;
	controlKey[SimonControl_TurboB] = DIK_R;
	controlKey[SimonControl_A] = DIK_D;
	controlKey[SimonControl_B] = DIK_F;
}





