#pragma once
namespace ggEngine {
	class EventArg {

	};
}