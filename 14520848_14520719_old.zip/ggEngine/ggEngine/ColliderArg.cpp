#include "ColliderArg.h"

ggEngine::ColliderArg::ColliderArg()
{
}

ggEngine::ColliderArg::~ColliderArg()
{
}
