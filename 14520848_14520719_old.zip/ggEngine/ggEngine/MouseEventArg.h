#pragma once
#include "EventArg.h"
namespace ggEngine {
	class MouseEventArg :public EventArg {

	};
}