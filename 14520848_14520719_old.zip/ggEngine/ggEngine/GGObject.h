#pragma once
namespace ggEngine {
	class GGObject {
	public:
		virtual void Destroy(){}
	};
}