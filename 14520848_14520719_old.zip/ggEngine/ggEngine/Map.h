#pragma once
#include <d3d9.h>
#include "ConstantEnum.h"
	class Map {
	public:
		Map();
		~Map();
		int width;
		int height;		
	};