#include "Map.h"

	Map::Map()
	{
		this->width = WINDOW_WIDTH;
		this->height = WINDOW_HEIGHT;
	}
	Map::~Map()
	{
	}

